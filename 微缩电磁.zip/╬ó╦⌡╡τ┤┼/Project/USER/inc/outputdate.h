#ifndef __OUTPUTDATE_H__
#define __OUTPUTDATE_H__

#include "zf_uart.h"
#include "headfile.h"


void datasend(void);

#endif
